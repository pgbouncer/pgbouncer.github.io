/*
 * PgBouncer - Lightweight connection pooler for PostgreSQL.
 *
 * Copyright (c) 2007-2009  Marko Kreen, Skype Technologies OÜ
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/* old style V2 header: len:4b code:4b */
#define OLD_HEADER_LEN  8
/* new style V3 packet header len - type:1b, len:4b */
#define NEW_HEADER_LEN  5

/*
 * parsed packet header, plus whatever data is
 * available in SBuf for this packet.
 *
 * if (pkt->len == mbuf_avail(&pkt->data))
 *     packet is fully in buffer
 *
 * get_header() points pkt->data.pos after header.
 * to packet body.
 */
struct PktHdr {
	unsigned type;
	unsigned len;
	struct MBuf data;
};

PktBuf *new_welcome_msg(void);

bool get_header(struct MBuf *data, PktHdr *pkt) _MUSTCHECK;

/* render the unparsed bytes of a packet header as hex, for error messages */
const char *hdr2hex(const struct MBuf *data, char *buf, unsigned buflen);

/*
 * Dispatches a fully buffered packet to the appropriate protocol handler. It
 * is responsible for rewinding the packet body to the start before handling.
 */
typedef bool (*pkt_handler_cb)(PgSocket *sk, PktHdr *pkt);

/* shared SBUF_EV_PKT_CALLBACK handler for client and server sockets */
bool process_pkt_callback(PgSocket *sk, struct MBuf *data, pkt_handler_cb handle_complete_packet) _MUSTCHECK;

bool send_pooler_error(PgSocket *client, bool send_ready, const char *sqlstate, bool level_fatal, const char *msg) /*_MUSTCHECK*/;
void log_server_error(const char *note, PktHdr *pkt);
void parse_server_error(PktHdr *pkt, const char **level_p, const char **msg_p, const char **sqlstate_p);

bool add_welcome_parameter(PgPool *pool, const char *key, const char *val) _MUSTCHECK;
void finish_welcome_msg(PgSocket *server);
bool welcome_client(PgSocket *client) _MUSTCHECK;

bool answer_authreq(PgSocket *server, PktHdr *pkt) _MUSTCHECK;

bool send_startup_message(PgSocket *server) _MUSTCHECK;
bool send_sslreq_packet(PgSocket *server) _MUSTCHECK;

/* reset the packet header and free the backing buffer */
static inline void free_header(PktHdr *pkt)
{
	mbuf_free(&pkt->data);
	pkt->type = 0;
	pkt->len = 0;
}

/* is packet completely in our buffer */
static inline bool incomplete_pkt(const PktHdr *pkt)
{
	return mbuf_written(&pkt->data) != pkt->len;
}

/* is packet header completely in buffer */
static inline bool incomplete_header(const struct MBuf *data)
{
	uint32_t avail = mbuf_avail_for_read(data);
	if (avail >= OLD_HEADER_LEN)
		return false;
	if (avail < NEW_HEADER_LEN)
		return true;
	/* is it old V2 header? */
	return data->data[data->read_pos] == 0;
}

/*
 * rewind the body of a v3 packet. Does not work for v2 packets, e.g. startup
 * packets
 */
static inline void pkt_rewind_v3(PktHdr *pkt)
{
	pkt->data.read_pos = NEW_HEADER_LEN;
}

/*
 * rewind the body of a v2 packet. Does not work for v3 packets, i.e.
 * everything except a startup packet
 */
static inline void pkt_rewind_v2(PktHdr *pkt)
{
	pkt->data.read_pos = OLD_HEADER_LEN;
}

/* one char desc */
static inline char pkt_desc(const PktHdr *pkt)
{
	return pkt->type > 256 ? '!' : pkt->type;
}
