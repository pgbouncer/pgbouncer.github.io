#! /bin/sh

./lib/mk/std-autogen.sh ./lib
