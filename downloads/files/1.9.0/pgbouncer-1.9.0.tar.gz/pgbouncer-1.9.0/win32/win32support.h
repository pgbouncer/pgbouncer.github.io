/* redirect main() */
#define main(a,b) real_main(a,b)
int real_main(int argc, char *argv[]);
